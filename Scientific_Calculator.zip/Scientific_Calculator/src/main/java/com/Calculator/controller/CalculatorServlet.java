package com.Calculator.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.String;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalculatorServlet
 */
@WebServlet("/CalculatorServlet")
public class CalculatorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * Default constructor.
     */
    public CalculatorServlet() {
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
//      response.getWriter().append("Served at: ").append(request.getContextPath());
        
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Servlet Calculator</title></head><body>");

        double n1 = Double.parseDouble(request.getParameter("firstnumber"));
        double n2 = Double.parseDouble(request.getParameter("secondnumber"));

        double result=0;
        String calculator = request.getParameter("calculator");
        
        if (calculator.equals("add"))
            result = n1 + n2;
        else if (calculator.equals("sub"))
            result = n1 - n2;
        else if (calculator.equals("mult"))
            result = n1 * n2;
        else if (calculator.equals("div"))
            result = n1 / n2;
        else if (calculator.equals("per"))
            result = (n1 / n2) * 100;
        else if (calculator.equals("sq"))
            result = n1 * n1;
        else if (calculator.equals("sqrt"))
            result = Math.sqrt(n1);

        out.println("<h1>Result=" + result + "</h1>");
        out.println("</body></html>");

    }

}
